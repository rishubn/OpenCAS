package org.mathlib.core;

import java.util.HashMap;
import java.util.Map;

public class FunctionList {
	private static Map<String,Function> fMap = new HashMap<String,Function>();
	
	public static void addFunc(Function f){
		fMap.put(f.toString(), f);
	}
	
	public static Map<String, Function> getFuncMap(){
		return fMap;
	}
}
