package org.mathlib.core;

public class Add extends Operator {


	public Add() {
		super("+", 4);
	}

	public double operation(double... args) {
		return args[0] + args[1]; 
	}


}
