package org.mathlib.core;

public class Sine extends Function{

	public double operation(double d){

    }


}
