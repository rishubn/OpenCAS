package org.mathlib.core;

import java.util.HashMap;
import java.util.Map;

public class OperatorList {
	private static Map<String,Operator> oMap = new HashMap<String,Operator>();
	
	public static void addOp(Operator o){
		oMap.put(o.toString(), o);
	}
	
	public static Map<String, Operator> getOpMap(){
		return oMap;
	}
}
