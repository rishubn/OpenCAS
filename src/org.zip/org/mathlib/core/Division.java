package org.mathlib.core;

public class Division extends Operator{
	public Division(){
		super("/",3);
	}

	@Override
	public double operation(double... args) {
		return args[1] / args[0];
	}
	
}
