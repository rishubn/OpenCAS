package org.mathlib.core;

public class Subtract extends Operator {

	public Subtract(){
		super("-",4);
	}
	public double operation(double... args) {
		return args[1] - args[0];
	}

}
