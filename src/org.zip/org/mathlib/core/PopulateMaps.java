package org.mathlib.core;

public class PopulateMaps {
	public static void Populate(){
		OperatorList.addOp(new Add());
		OperatorList.addOp(new Subtract());
		OperatorList.addOp(new Multiply());
		OperatorList.addOp(new Division());
		OperatorList.addOp(new Exponent());
		OperatorList.addOp(new Paran(")"));
		OperatorList.addOp(new Paran("("));
		OperatorList.addOp(new Modulo());
	}
}
