package org.mathlib.exceptions;

public class MisMatchedParenthesisException extends Exception{
	public MisMatchedParenthesisException(){
		super();
	}
}
